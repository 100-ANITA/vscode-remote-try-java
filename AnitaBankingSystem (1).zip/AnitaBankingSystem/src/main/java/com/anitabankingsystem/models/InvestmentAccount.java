package com.anitabankingsystem.models;

public class InvestmentAccount extends Account implements InterestBearing {
    private static final double RATE = 0.05; // 5%
    private static final double MIN_DEPOSIT = 500.0;

    // NOTE: constructor does not throw — we enforce min on deposit
    public InvestmentAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    @Override
    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Amount must be > 0");
        // enforce min deposit only for the first deposit when balance < MIN_DEPOSIT
        if (getBalance() < MIN_DEPOSIT && (getBalance() + amount) < MIN_DEPOSIT) {
            throw new IllegalArgumentException("Investment accounts require a minimum balance of " + MIN_DEPOSIT);
        }
        setBalance(getBalance() + amount);
    }

    @Override
    public void withdraw(double amount) {
        if (amount > 0 && amount <= getBalance()) setBalance(getBalance() - amount);
        else throw new IllegalArgumentException("Insufficient funds");
    }

    @Override
    public void applyInterest() {
        deposit(getBalance() * RATE);
    }
}
