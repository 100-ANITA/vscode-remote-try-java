package com.anitabankingsystem.models;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private final int id;
    private final String firstName;
    private final String surname;
    private final String address;
    private final String username;
    private final String password;
    private final String company;
    private final String companyAddress;
    private final List<Account> accounts = new ArrayList<>();

    public Customer(int id, String firstName, String surname, String address, String username, String password, String company, String companyAddress) {
        this.id = id;
        this.firstName = firstName;
        this.surname = surname;
        this.address = address;
        this.username = username;
        this.password = password;
        this.company = company;
        this.companyAddress = companyAddress;
    }

    public Customer(int id, String firstName, String surname, String address, String username, String password) {
        this(id, firstName, surname, address, username, password, null, null);
    }

    public void addAccount(Account account) { accounts.add(account); }
    public List<Account> getAccounts() { return accounts; }

    public int getId() { return id; }
    public String getFirstName() { return firstName; }
    public String getSurname() { return surname; }
    public String getAddress() { return address; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getCompany() { return company; }
    public String getCompanyAddress() { return companyAddress; }
}
