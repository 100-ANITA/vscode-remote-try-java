package com.anitabankingsystem.models;

public interface InterestBearing {
    void applyInterest();
}
