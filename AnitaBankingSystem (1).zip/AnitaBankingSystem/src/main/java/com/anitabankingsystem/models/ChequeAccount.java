package com.anitabankingsystem.models;

public class ChequeAccount extends Account {
    public ChequeAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) setBalance(getBalance() + amount);
    }

    @Override
    public void withdraw(double amount) {
        if (amount > 0 && amount <= getBalance()) setBalance(getBalance() - amount);
        else throw new IllegalArgumentException("Insufficient funds");
    }
}
