package com.anitabankingsystem.models;

public class SavingsAccount extends Account implements InterestBearing {
    private static final double RATE = 0.0005; // 0.05%

    public SavingsAccount(String accountNumber, double balance) {
        super(accountNumber, balance);
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) setBalance(getBalance() + amount);
        else throw new IllegalArgumentException("Amount must be > 0");
    }

    @Override
    public void withdraw(double amount) {
        // Business rule: no withdrawals allowed for Savings in this app
        throw new IllegalArgumentException("No withdrawals allowed for Savings accounts");
    }

    @Override
    public void applyInterest() {
        deposit(getBalance() * RATE);
    }
}
