package com.anitabankingsystem.views;

import com.anitabankingsystem.models.Account;
import com.anitabankingsystem.models.Customer;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AccountView {
    private final Stage stage = new Stage();
    private final ListView<String> accountList = new ListView<>();
    private final TextField amountField = new TextField();
    private final Button depositButton = new Button("Deposit");
    private final Button withdrawButton = new Button("Withdraw");
    private final Button interestButton = new Button("Apply Interest");
    private final Label statusLabel = new Label();

    public AccountView(Customer customer) {
        VBox vbox = new VBox(8);
        for (Account acc : customer.getAccounts()) {
            accountList.getItems().add(acc.getAccountNumber() + " (" + acc.getClass().getSimpleName() + ") Balance: " + String.format("%.2f", acc.getBalance()));
        }

        vbox.getChildren().addAll(new Label("Accounts:"), accountList, new Label("Amount:"), amountField, depositButton, withdrawButton, interestButton, statusLabel);

        Scene scene = new Scene(vbox, 360, 300);
        stage.setTitle("Accounts - " + customer.getFirstName());
        stage.setScene(scene);
        stage.show();
    }

    public Stage getStage() { return stage; }
    public ListView<String> getAccountList() { return accountList; }
    public TextField getAmountField() { return amountField; }
    public Button getDepositButton() { return depositButton; }
    public Button getWithdrawButton() { return withdrawButton; }
    public Button getInterestButton() { return interestButton; }
    public Label getStatusLabel() { return statusLabel; }
}
