package com.anitabankingsystem.controllers;

import com.anitabankingsystem.daos.CustomerDAO;
import com.anitabankingsystem.models.Customer;
import com.anitabankingsystem.views.AccountView;
import com.anitabankingsystem.views.LoginView;

import java.sql.SQLException;

public class LoginController {
    private final LoginView view;
    private final CustomerDAO dao;

    public LoginController(LoginView view, CustomerDAO dao) {
        this.view = view;
        this.dao = dao;
        view.getLoginButton().setOnAction(e -> login());
    }

    private void login() {
        String user = view.getUsernameField().getText();
        String pass = view.getPasswordField().getText();

        try {
            Customer customer = dao.getCustomer(user);
            if (customer != null && customer.getPassword().equals(pass)) {
                view.getStatusLabel().setText("Success");
                // Open account view and wire controller
                AccountView accountView = new AccountView(customer);
                new AccountController(accountView, dao, customer);
                // close login window
                view.getStage().close();
            } else {
                view.getStatusLabel().setText("Invalid username/password");
            }
        } catch (SQLException e) {
            view.getStatusLabel().setText("DB error: " + e.getMessage());
        }
    }
}
