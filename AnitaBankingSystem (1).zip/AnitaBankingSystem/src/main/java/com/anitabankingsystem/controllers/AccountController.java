package com.anitabankingsystem.controllers;

import com.anitabankingsystem.daos.CustomerDAO;
import com.anitabankingsystem.models.Account;
import com.anitabankingsystem.models.Customer;
import com.anitabankingsystem.models.InterestBearing;
import com.anitabankingsystem.views.AccountView;

public class AccountController {
    private final AccountView view;
    private final CustomerDAO dao;
    private final Customer customer;

    public AccountController(AccountView view, CustomerDAO dao, Customer customer) {
        this.view = view;
        this.dao = dao;
        this.customer = customer;

        // initialize UI list and handlers
        updateList();

        view.getDepositButton().setOnAction(e -> deposit());
        view.getWithdrawButton().setOnAction(e -> withdraw());
        view.getInterestButton().setOnAction(e -> interest());
    }

    private void deposit() {
        try {
            Account acc = getAcc();
            double amt = parseAmount();
            acc.deposit(amt);
            dao.updateBalance(acc);        // persist
            updateList();
            view.getStatusLabel().setText("Deposit done");
        } catch (Exception e) {
            view.getStatusLabel().setText(e.getMessage());
        }
    }

    private void withdraw() {
        try {
            Account acc = getAcc();
            double amt = parseAmount();
            acc.withdraw(amt);
            dao.updateBalance(acc);        // persist
            updateList();
            view.getStatusLabel().setText("Withdrawal done");
        } catch (Exception e) {
            view.getStatusLabel().setText(e.getMessage());
        }
    }

    private void interest() {
        try {
            Account acc = getAcc();
            if (acc instanceof InterestBearing ib) {
                ib.applyInterest();
                dao.updateBalance(acc);
                updateList();
                view.getStatusLabel().setText("Interest applied");
            } else {
                view.getStatusLabel().setText("Account not interest-bearing");
            }
        } catch (Exception e) {
            view.getStatusLabel().setText(e.getMessage());
        }
    }

    private Account getAcc() {
        String item = view.getAccountList().getSelectionModel().getSelectedItem();
        if (item == null || item.isBlank()) throw new IllegalArgumentException("Select an account first");

        String num = item.split(" ")[0].trim();
        for (Account a : customer.getAccounts()) {
            if (a.getAccountNumber().equals(num)) return a;
        }
        throw new IllegalArgumentException("Selected account not found");
    }

    private double parseAmount() {
        String txt = view.getAmountField().getText();
        if (txt == null || txt.isBlank()) throw new IllegalArgumentException("Enter an amount");
        double amt;
        try {
            amt = Double.parseDouble(txt);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Invalid amount format");
        }
        if (amt <= 0) throw new IllegalArgumentException("Amount must be > 0");
        return amt;
    }

    private void updateList() {
        view.getAccountList().getItems().clear();
        for (Account acc : customer.getAccounts()) {
            view.getAccountList().getItems().add(
                    acc.getAccountNumber() +
                            " (" + acc.getClass().getSimpleName() + ") Balance: " +
                            String.format("%.2f", acc.getBalance())
            );
        }
    }
}
