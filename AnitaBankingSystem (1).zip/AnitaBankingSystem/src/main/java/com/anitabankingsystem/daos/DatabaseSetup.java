package com.anitabankingsystem.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseSetup {
    private static final String URL = "jdbc:h2:./bankdb;AUTO_SERVER=TRUE";


    public static Connection getConn() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void init() throws SQLException {
        try (Connection conn = getConn(); Statement stmt = conn.createStatement()) {

            stmt.execute("CREATE TABLE IF NOT EXISTS customers (" +
                    "id INT PRIMARY KEY AUTO_INCREMENT, " +
                    "first_name VARCHAR, " +
                    "surname VARCHAR, " +
                    "address VARCHAR, " +
                    "username VARCHAR UNIQUE, " +
                    "password VARCHAR, " +
                    "company VARCHAR, " +
                    "company_address VARCHAR)");

            stmt.execute("CREATE TABLE IF NOT EXISTS accounts (" +
                    "account_number VARCHAR PRIMARY KEY, " +
                    "balance DOUBLE, " +
                    "customer_id INT, " +
                    "type VARCHAR, " +
                    "FOREIGN KEY (customer_id) REFERENCES customers(id))");

            // Only insert sample data if table empty
            var rs = stmt.executeQuery("SELECT COUNT(*) FROM customers");
            rs.next();
            if (rs.getInt(1) == 0) {
                for (int i = 1; i <= 10; i++) {
                    stmt.execute("INSERT INTO customers (first_name, surname, address, username, password, company, company_address) " +
                            "VALUES ('F" + i + "', 'L" + i + "', 'A" + i + "', 'u" + i + "', 'p" + i + "', 'C" + i + "', 'CA" + i + "')");
                    int id = i;
                    stmt.execute("INSERT INTO accounts (account_number, balance, customer_id, type) VALUES ('A" + i + "S', 1000, " + id + ", 'SavingsAccount')");
                    if (i % 2 == 0)
                        stmt.execute("INSERT INTO accounts (account_number, balance, customer_id, type) VALUES ('A" + i + "I', 600, " + id + ", 'InvestmentAccount')");
                    if (i % 3 == 0)
                        stmt.execute("INSERT INTO accounts (account_number, balance, customer_id, type) VALUES ('A" + i + "C', 2000, " + id + ", 'ChequeAccount')");
                }
            }
        }
    }
}
