package com.anitabankingsystem.daos;

import com.anitabankingsystem.models.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CustomerDAO {

    public Customer getCustomer(String username) throws SQLException {
        try (Connection conn = DatabaseSetup.getConn();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM customers WHERE username = ?")) {

            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Customer c = new Customer(
                        rs.getInt("id"),
                        rs.getString("first_name"),
                        rs.getString("surname"),
                        rs.getString("address"),
                        username,
                        rs.getString("password"),
                        rs.getString("company"),
                        rs.getString("company_address")
                );
                c.getAccounts().addAll(getAccounts(rs.getInt("id")));
                return c;
            }
            return null;
        }
    }

    private Collection<Account> getAccounts(int id) throws SQLException {
        List<Account> accs = new ArrayList<>();
        try (Connection conn = DatabaseSetup.getConn();
             PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM accounts WHERE customer_id = ?")) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String type = rs.getString("type");
                double bal = rs.getDouble("balance");
                String num = rs.getString("account_number");
                Account a;
                if ("SavingsAccount".equals(type)) a = new SavingsAccount(num, bal);
                else if ("InvestmentAccount".equals(type)) a = new InvestmentAccount(num, bal);
                else a = new ChequeAccount(num, bal);
                accs.add(a);
            }
        }
        return accs;
    }

    public void updateBalance(Account acc) throws SQLException {
        try (Connection conn = DatabaseSetup.getConn();
             PreparedStatement pstmt = conn.prepareStatement("UPDATE accounts SET balance = ? WHERE account_number = ?")) {
            pstmt.setDouble(1, acc.getBalance());
            pstmt.setString(2, acc.getAccountNumber());
            pstmt.executeUpdate();
        }
    }
}
