package com.anitabankingsystem;

import com.anitabankingsystem.daos.CustomerDAO;
import com.anitabankingsystem.daos.DatabaseSetup;
import com.anitabankingsystem.views.LoginView;
import com.anitabankingsystem.controllers.LoginController;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

    private static CustomerDAO dao;

    public static void main(String[] args) {
        try {
            // Initialize DB only once before JavaFX starts
            DatabaseSetup.init();
            dao = new CustomerDAO();

            // Launch the JavaFX application
            launch(args);

        } catch (Exception e) {
            System.out.println("Database initialization failed:");
            e.printStackTrace();
        }
    }

    @Override
    public void start(Stage stage) {
        // Start Login View
        LoginView loginView = new LoginView();
        loginView.start(stage);

        // Attach controller
        new LoginController(loginView, dao);
    }
}
