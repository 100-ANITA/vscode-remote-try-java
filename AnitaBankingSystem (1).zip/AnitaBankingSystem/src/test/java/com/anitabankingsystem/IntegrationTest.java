package com.anitabankingsystem;

import com.anitabankingsystem.daos.DatabaseSetup;
import com.anitabankingsystem.daos.CustomerDAO;
import com.anitabankingsystem.models.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class IntegrationTest {
    @BeforeAll
    static void setup() throws SQLException {
        DatabaseSetup.init();
    }

    @Test
    void testFlow() throws SQLException {
        CustomerDAO dao = new CustomerDAO();
        Customer c = dao.getCustomer("u1");
        assertNotNull(c);
        Account a = c.getAccounts().get(0);
        double old = a.getBalance();
        a.deposit(100);
        dao.updateBalance(a);
        Customer newC = dao.getCustomer("u1");
        assertEquals(old + 100, newC.getAccounts().get(0).getBalance());
    }
}